package com.booknara.booknaraPrj.ebook.dto;

import lombok.Data;

@Data
public class License {
    private String name;
    private String url;
}
