package com.booknara.booknaraPrj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooknaraPrjApplicationTests {

	@Test
	void contextLoads() {

	}
}
