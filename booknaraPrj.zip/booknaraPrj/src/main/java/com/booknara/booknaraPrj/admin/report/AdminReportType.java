package com.booknara.booknaraPrj.admin.report;

public enum AdminReportType {
    FEED, COMMENT
}
